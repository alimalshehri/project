import { OfficeType, AttachmentType } from '../types/FormTypes';

export const officeTypes: OfficeType[] = [
  { value: 'consulting', label: 'استشاري' },
  { value: 'engineering', label: 'هندسي' },
  { value: 'surveying', label: 'مساحي' }
];

export const attachmentTypes: AttachmentType[] = [
  { key: 'engineersLicense', label: 'ترخيص الهيئة السعودية للمهندسين للمكتب', required: true },
  { key: 'commercialRegister', label: 'السجل التجاري للمكتب', required: true },
  { key: 'municipalClassification', label: 'شهادة تصنيف بلدي للمكتب', required: true },
  { key: 'nationalAddress', label: 'العنوان الوطني للمكتب', required: true },
  { key: 'municipalLicense', label: 'رخصة البلدية للمكتب', required: true },
  { key: 'ownerId', label: 'هوية صاحب المكتب', required: true },
  { key: 'ownerMembership', label: 'عضوية الهيئة السعودية للمهندسين لصاحب المكتب', required: true },
  { key: 'educationCertificate', label: 'الشهادة العلمية لصاحب المكتب', required: true }
];