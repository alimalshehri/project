import React from 'react';
import { AlertCircle, ChevronDown } from 'lucide-react';
import { FormData, MunicipalLicense } from '../../types/FormTypes';
import { officeTypes } from '../../constants/formConstants';

interface Step1Props {
  formData: FormData;
  updateFormData: (updates: Partial<FormData>) => void;
  municipalDropdownOpen: boolean;
  setMunicipalDropdownOpen: (open: boolean) => void;
  selectMunicipalLicense: (license: MunicipalLicense) => void;
}

const Step1BasicDataAndVerification: React.FC<Step1Props> = ({
  formData,
  updateFormData,
  municipalDropdownOpen,
  setMunicipalDropdownOpen,
  selectMunicipalLicense
}) => {
  return (
    <div className="space-y-3">
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-2">
        <div className="flex items-start">
          <AlertCircle className="h-3 w-3 text-yellow-600 mt-0.5 ml-2 flex-shrink-0" />
          <p className="text-yellow-800 text-xs leading-relaxed">
            في حال كان المكتب مسجل سابقاً في أمان المدينة المنورة، يرجى التأكد من إدخال بيانات مطابقة للبيانات المسجلة مسبقاً
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1">
            نوع المكتب <span className="text-red-500">*</span>
          </label>
          <select
            value={formData.officeType}
            onChange={(e) => updateFormData({ officeType: e.target.value })}
            className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">اختر نوع المكتب</option>
            {officeTypes.map(type => (
              <option key={type.value} value={type.value}>
                {type.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1">
            رقم هوية صاحب المكتب <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={formData.ownerId}
            onChange={(e) => updateFormData({ ownerId: e.target.value })}
            className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            placeholder="أدخل رقم الهوية"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1">
            {formData.officeType === 'surveying' 
              ? 'رقم ترخيص الهيئة العامة للمساحة' 
              : 'رقم ترخيص الهيئة السعودية للمهندسين'
            } <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={formData.licenseNumber}
            onChange={(e) => updateFormData({ licenseNumber: e.target.value })}
            className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            placeholder="أدخل رقم الترخيص"
          />
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-2 mt-3">
        <div className="flex items-start">
          <AlertCircle className="h-3 w-3 text-blue-600 mt-0.5 ml-2 flex-shrink-0" />
          <p className="text-blue-800 text-xs">
            {formData.officeType && formData.ownerId && formData.licenseNumber 
              ? 'يرجى التحقق من مطابقة البيانات من التكامل قبل الاستكمال'
              : 'سيتم جلب البيانات من التكامل بعد إدخال البيانات الأساسية'
            }
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2">
        <div className="bg-gray-50 p-2 rounded-lg">
          <h3 className="font-semibold text-gray-800 mb-1 text-xs">بيانات المكتب</h3>
          <div className="space-y-0.5 text-xs">
            <div><span className="font-medium">اسم المكتب:</span> <span className={formData.verificationData.officeName ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.officeName || '---'}</span></div>
            <div><span className="font-medium">كود المكتب:</span> <span className={formData.verificationData.officeCode ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.officeCode || '---'}</span></div>
          </div>
        </div>

        <div className="bg-gray-50 p-2 rounded-lg">
          <h3 className="font-semibold text-gray-800 mb-1 text-xs">ترخيص الهيئة السعودية</h3>
          <div className="space-y-0.5 text-xs">
            <div><span className="font-medium">رقم الترخيص:</span> <span className={formData.verificationData.engineersLicense ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.engineersLicense || '---'}</span></div>
            <div><span className="font-medium">البداية:</span> <span className={formData.verificationData.engineersLicenseStart ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.engineersLicenseStart || '---'}</span></div>
            <div><span className="font-medium">الانتهاء:</span> <span className={formData.verificationData.engineersLicenseEnd ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.engineersLicenseEnd || '---'}</span></div>
          </div>
        </div>

        <div className="bg-gray-50 p-2 rounded-lg">
          <h3 className="font-semibold text-gray-800 mb-1 text-xs">السجل التجاري</h3>
          <div className="space-y-0.5 text-xs">
            <div><span className="font-medium">رقم السجل:</span> <span className={formData.verificationData.commercialRegister ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.commercialRegister || '---'}</span></div>
            <div><span className="font-medium">البداية:</span> <span className={formData.verificationData.commercialRegisterStart ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.commercialRegisterStart || '---'}</span></div>
            <div><span className="font-medium">الانتهاء:</span> <span className={formData.verificationData.commercialRegisterEnd ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.commercialRegisterEnd || '---'}</span></div>
          </div>
        </div>

        <div className="bg-gray-50 p-2 rounded-lg">
          <h3 className="font-semibold text-gray-800 mb-1 text-xs">رخصة البلدية</h3>
          <div className="relative">
            <button
              onClick={() => setMunicipalDropdownOpen(!municipalDropdownOpen)}
              className="w-full px-2 py-1 text-xs border border-gray-300 rounded-md bg-white text-right flex items-center justify-between focus:outline-none focus:ring-1 focus:ring-blue-500"
              disabled={formData.verificationData.municipalLicenses.length === 0}
            >
              <span className={formData.verificationData.selectedMunicipalLicense ? 'text-gray-900' : 'text-gray-400'}>
                {formData.verificationData.selectedMunicipalLicense 
                  ? formData.verificationData.selectedMunicipalLicense.licenseNumber
                  : formData.verificationData.municipalLicenses.length > 0 
                    ? 'اختر رخصة البلدية'
                    : '---'
                }
              </span>
              {formData.verificationData.municipalLicenses.length > 0 && (
                <ChevronDown className="h-3 w-3 text-gray-400" />
              )}
            </button>
            
            {municipalDropdownOpen && formData.verificationData.municipalLicenses.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-300 rounded-md shadow-lg z-10 max-h-32 overflow-y-auto">
                {formData.verificationData.municipalLicenses.map((license) => (
                  <div 
                    key={license.id} 
                    className="p-2 hover:bg-gray-50 cursor-pointer"
                    onClick={() => selectMunicipalLicense(license)}
                  >
                    <div className="text-xs">
                      <div className="font-medium text-gray-900">{license.licenseNumber}</div>
                      <div className="text-gray-600">{license.municipalityName}</div>
                      <div className="text-gray-500">انتهاء: {license.licenseEnd}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {formData.verificationData.selectedMunicipalLicense && (
            <div className="mt-1 space-y-0.5 text-xs">
              <div><span className="font-medium">الأمانة:</span> <span className="text-gray-900">{formData.verificationData.selectedMunicipalLicense.municipalityName}</span></div>
              <div><span className="font-medium">الانتهاء:</span> <span className="text-gray-900">{formData.verificationData.selectedMunicipalLicense.licenseEnd}</span></div>
            </div>
          )}
        </div>

        <div className="bg-gray-50 p-2 rounded-lg">
          <h3 className="font-semibold text-gray-800 mb-1 text-xs">التصنيف البلدي</h3>
          <div className="space-y-0.5 text-xs">
            <div><span className="font-medium">رقم التصنيف:</span> <span className={formData.verificationData.municipalClassification ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.municipalClassification || '---'}</span></div>
            <div><span className="font-medium">الدرجة:</span> <span className={formData.verificationData.classificationDegree ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.classificationDegree || '---'}</span></div>
            <div><span className="font-medium">الانتهاء:</span> <span className={formData.verificationData.classificationEnd ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.classificationEnd || '---'}</span></div>
          </div>
        </div>

        <div className="bg-gray-50 p-2 rounded-lg">
          <h3 className="font-semibold text-gray-800 mb-1 text-xs">العنوان الوطني</h3>
          <div className="space-y-0.5 text-xs">
            <div><span className="font-medium">رقم العنوان:</span> <span className={formData.verificationData.nationalAddress ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.nationalAddress || '---'}</span></div>
            <div><span className="font-medium">البيانات:</span> <span className={formData.verificationData.nationalAddressData ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.nationalAddressData || '---'}</span></div>
            <div><span className="font-medium">الانتهاء:</span> <span className={formData.verificationData.nationalAddressEnd ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.nationalAddressEnd || '---'}</span></div>
          </div>
        </div>

        <div className="bg-gray-50 p-2 rounded-lg">
          <h3 className="font-semibold text-gray-800 mb-1 text-xs">هوية المالك</h3>
          <div className="space-y-0.5 text-xs">
            <div><span className="font-medium">رقم الهوية:</span> <span className={formData.verificationData.ownerId ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.ownerId || '---'}</span></div>
            <div><span className="font-medium">الانتهاء:</span> <span className={formData.verificationData.ownerIdEnd ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.ownerIdEnd || '---'}</span></div>
          </div>
        </div>

        <div className="bg-gray-50 p-2 rounded-lg">
          <h3 className="font-semibold text-gray-800 mb-1 text-xs">عضوية الهيئة</h3>
          <div className="space-y-0.5 text-xs">
            <div><span className="font-medium">رقم العضوية:</span> <span className={formData.verificationData.ownerMembership ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.ownerMembership || '---'}</span></div>
            <div><span className="font-medium">الانتهاء:</span> <span className={formData.verificationData.ownerMembershipEnd ? 'text-gray-900' : 'text-gray-400'}>{formData.verificationData.ownerMembershipEnd || '---'}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Step1BasicDataAndVerification;