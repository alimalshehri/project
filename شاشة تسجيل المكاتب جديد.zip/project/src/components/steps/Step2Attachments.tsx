import React from 'react';
import { Upload, CheckCircle } from 'lucide-react';
import { FormData } from '../../types/FormTypes';
import { attachmentTypes } from '../../constants/formConstants';

interface Step2Props {
  formData: FormData;
  handleFileUpload: (key: string, file: File | null) => void;
}

const Step2Attachments: React.FC<Step2Props> = ({ formData, handleFileUpload }) => {
  return (
    <div className="space-y-3">
      <div className="bg-green-50 border border-green-200 rounded-lg p-2">
        <div className="flex items-start">
          <Upload className="h-3 w-3 text-green-600 mt-0.5 ml-2 flex-shrink-0" />
          <p className="text-green-800 text-xs">
            يرجى إرفاق جميع المستندات المطلوبة أدناه
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        {attachmentTypes.map((attachment) => (
          <div key={attachment.key} className="border border-gray-200 rounded-lg p-2">
            <label className="block text-xs font-medium text-gray-700 mb-1">
              {attachment.label} {attachment.required && <span className="text-red-500">*</span>}
            </label>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <input
                type="file"
                accept=".pdf,.jpg,.jpeg,.png"
                onChange={(e) => handleFileUpload(attachment.key, e.target.files?.[0] || null)}
                className="flex-1 text-xs text-gray-500 file:mr-2 file:py-1 file:px-2 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
              />
              {formData.attachments[attachment.key as keyof typeof formData.attachments] && (
                <CheckCircle className="h-3 w-3 text-green-500 flex-shrink-0" />
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Step2Attachments;