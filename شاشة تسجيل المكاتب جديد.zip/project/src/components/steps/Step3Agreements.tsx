import React from 'react';
import { FileText } from 'lucide-react';
import { FormData } from '../../types/FormTypes';

interface Step3Props {
  formData: FormData;
  updateFormData: (updates: Partial<FormData>) => void;
}

const Step3Agreements: React.FC<Step3Props> = ({ formData, updateFormData }) => {
  return (
    <div className="space-y-3">
      <div className="bg-purple-50 border border-purple-200 rounded-lg p-2">
        <div className="flex items-start">
          <FileText className="h-3 w-3 text-purple-600 mt-0.5 ml-2 flex-shrink-0" />
          <p className="text-purple-800 text-xs">
            يرجى مراجعة جميع الاتفاقيات والموافقة عليها للمتابعة
          </p>
        </div>
      </div>

      <div className="space-y-2">
        <div className="border border-gray-200 rounded-lg p-2">
          <div className="flex items-start space-x-2 rtl:space-x-reverse">
            <input
              type="checkbox"
              id="feesAgreement"
              checked={formData.agreements.feesAgreement}
              onChange={(e) => updateFormData({
                agreements: { ...formData.agreements, feesAgreement: e.target.checked }
              })}
              className="mt-0.5 h-3 w-3 text-blue-600 border-gray-300 rounded focus:ring-blue-500 flex-shrink-0"
            />
            <label htmlFor="feesAgreement" className="text-xs text-gray-700">
              أوافق على دفع الرسوم المحددة في النظام وهي <span className="font-semibold text-blue-600">100 ريال شهرياً</span> رسوم شبكة
            </label>
          </div>
        </div>

        <div className="border border-gray-200 rounded-lg p-2">
          <div className="flex items-start space-x-2 rtl:space-x-reverse">
            <input
              type="checkbox"
              id="generalAgreement"
              checked={formData.agreements.generalAgreement}
              onChange={(e) => updateFormData({
                agreements: { ...formData.agreements, generalAgreement: e.target.checked }
              })}
              className="mt-0.5 h-3 w-3 text-blue-600 border-gray-300 rounded focus:ring-blue-500 flex-shrink-0"
            />
            <label htmlFor="generalAgreement" className="text-xs text-gray-700">
              أوافق على <span className="text-blue-600 underline cursor-pointer">الاتفاقية الموحدة للمكاتب والأمانة</span>
            </label>
          </div>
        </div>

        <div className="border border-gray-200 rounded-lg p-2">
          <div className="flex items-start space-x-2 rtl:space-x-reverse">
            <input
              type="checkbox"
              id="confidentialityAgreement"
              checked={formData.agreements.confidentialityAgreement}
              onChange={(e) => updateFormData({
                agreements: { ...formData.agreements, confidentialityAgreement: e.target.checked }
              })}
              className="mt-0.5 h-3 w-3 text-blue-600 border-gray-300 rounded focus:ring-blue-500 flex-shrink-0"
            />
            <label htmlFor="confidentialityAgreement" className="text-xs text-gray-700">
              أوافق على <span className="text-blue-600 underline cursor-pointer">اتفاقية المحافظة على سرية المعلومات</span>
            </label>
          </div>
        </div>

        <div className="border border-gray-200 rounded-lg p-2">
          <div className="flex items-start space-x-2 rtl:space-x-reverse">
            <input
              type="checkbox"
              id="ethicsCharter"
              checked={formData.agreements.ethicsCharter}
              onChange={(e) => updateFormData({
                agreements: { ...formData.agreements, ethicsCharter: e.target.checked }
              })}
              className="mt-0.5 h-3 w-3 text-blue-600 border-gray-300 rounded focus:ring-blue-500 flex-shrink-0"
            />
            <label htmlFor="ethicsCharter" className="text-xs text-gray-700">
              أوافق على <span className="text-blue-600 underline cursor-pointer">ميثاق السلوك والأخلاق للمهندسين</span>
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Step3Agreements;