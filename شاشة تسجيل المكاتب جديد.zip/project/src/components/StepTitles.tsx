import React from 'react';

interface StepTitlesProps {
  currentStep: number;
  totalSteps: number;
}

const StepTitles: React.FC<StepTitlesProps> = ({ currentStep, totalSteps }) => {
  const titles = [
    'البيانات الأساسية والتحقق',
    'المرفقات',
    'الاتفاقيات'
  ];
  
  return (
    <div className="text-center mb-3">
      <h2 className="text-lg font-bold text-gray-800 mb-1">
        {titles[currentStep - 1]}
      </h2>
      <p className="text-xs text-gray-600">
        الخطوة {currentStep} من {totalSteps}
      </p>
    </div>
  );
};

export default StepTitles;