export interface MunicipalLicense {
  id: string;
  licenseNumber: string;
  municipalityName: string;
  licenseEnd: string;
}

export interface FormData {
  // Step 1 - Basic Data
  officeType: string;
  ownerId: string;
  licenseNumber: string;
  
  // Step 1 - Verification Data (from integration)
  verificationData: {
    officeName: string;
    officeCode: string;
    engineersLicense: string;
    engineersLicenseStart: string;
    engineersLicenseEnd: string;
    commercialRegister: string;
    commercialRegisterStart: string;
    commercialRegisterEnd: string;
    municipalLicenses: MunicipalLicense[];
    selectedMunicipalLicense: MunicipalLicense | null;
    municipalClassification: string;
    classificationDegree: string;
    classificationEnd: string;
    nationalAddress: string;
    nationalAddressData: string;
    nationalAddressEnd: string;
    ownerId: string;
    ownerIdEnd: string;
    ownerMembership: string;
    ownerMembershipEnd: string;
  };
  
  // Step 2 - Attachments
  attachments: {
    engineersLicense: File | null;
    commercialRegister: File | null;
    municipalClassification: File | null;
    nationalAddress: File | null;
    municipalLicense: File | null;
    ownerId: File | null;
    ownerMembership: File | null;
    educationCertificate: File | null;
  };
  
  // Step 3 - Agreements
  agreements: {
    feesAgreement: boolean;
    generalAgreement: boolean;
    confidentialityAgreement: boolean;
    ethicsCharter: boolean;
  };
}

export interface OfficeType {
  value: string;
  label: string;
}

export interface AttachmentType {
  key: string;
  label: string;
  required: boolean;
}