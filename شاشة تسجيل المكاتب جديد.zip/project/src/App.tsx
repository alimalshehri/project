import React, { useState, useEffect } from 'react';
import { ChevronRight, ChevronLeft, Building, CheckCircle } from 'lucide-react';
import { FormData, MunicipalLicense } from './types/FormTypes';
import StepIndicator from './components/StepIndicator';
import StepTitles from './components/StepTitles';
import Step1BasicDataAndVerification from './components/steps/Step1BasicDataAndVerification';
import Step2Attachments from './components/steps/Step2Attachments';
import Step3Agreements from './components/steps/Step3Agreements';
import { useFormValidation } from './hooks/useFormValidation';
import { fetchIntegrationData } from './services/integrationService';

function App() {
  const [currentStep, setCurrentStep] = useState(1);
  const [municipalDropdownOpen, setMunicipalDropdownOpen] = useState(false);
  const { isStepValid } = useFormValidation();
  
  const [formData, setFormData] = useState<FormData>({
    officeType: '',
    ownerId: '',
    licenseNumber: '',
    verificationData: {
      officeName: '',
      officeCode: '',
      engineersLicense: '',
      engineersLicenseStart: '',
      engineersLicenseEnd: '',
      commercialRegister: '',
      commercialRegisterStart: '',
      commercialRegisterEnd: '',
      municipalLicenses: [],
      selectedMunicipalLicense: null,
      municipalClassification: '',
      classificationDegree: '',
      classificationEnd: '',
      nationalAddress: '',
      nationalAddressData: '',
      nationalAddressEnd: '',
      ownerId: '',
      ownerIdEnd: '',
      ownerMembership: '',
      ownerMembershipEnd: ''
    },
    attachments: {
      engineersLicense: null,
      commercialRegister: null,
      municipalClassification: null,
      nationalAddress: null,
      municipalLicense: null,
      ownerId: null,
      ownerMembership: null,
      educationCertificate: null
    },
    agreements: {
      feesAgreement: false,
      generalAgreement: false,
      confidentialityAgreement: false,
      ethicsCharter: false
    }
  });

  const updateFormData = (updates: Partial<FormData>) => {
    setFormData(prev => ({ ...prev, ...updates }));
  };

  // Fetch integration data when basic data is complete
  useEffect(() => {
    if (formData.officeType && formData.ownerId && formData.licenseNumber) {
      fetchIntegrationData().then((data) => {
        updateFormData({
          verificationData: {
            ...data,
            selectedMunicipalLicense: null
          }
        });
      });
    } else {
      // Clear verification data when basic data is incomplete
      updateFormData({
        verificationData: {
          officeName: '',
          officeCode: '',
          engineersLicense: '',
          engineersLicenseStart: '',
          engineersLicenseEnd: '',
          commercialRegister: '',
          commercialRegisterStart: '',
          commercialRegisterEnd: '',
          municipalLicenses: [],
          selectedMunicipalLicense: null,
          municipalClassification: '',
          classificationDegree: '',
          classificationEnd: '',
          nationalAddress: '',
          nationalAddressData: '',
          nationalAddressEnd: '',
          ownerId: '',
          ownerIdEnd: '',
          ownerMembership: '',
          ownerMembershipEnd: ''
        }
      });
    }
  }, [formData.officeType, formData.ownerId, formData.licenseNumber]);

  const selectMunicipalLicense = (license: MunicipalLicense) => {
    updateFormData({
      verificationData: {
        ...formData.verificationData,
        selectedMunicipalLicense: license
      }
    });
    setMunicipalDropdownOpen(false);
  };

  const nextStep = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleFileUpload = (key: string, file: File | null) => {
    setFormData(prev => ({
      ...prev,
      attachments: {
        ...prev.attachments,
        [key]: file
      }
    }));
  };

  const handleSubmit = () => {
    alert('تم إرسال الطلب بنجاح!');
  };

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <Step1BasicDataAndVerification
            formData={formData}
            updateFormData={updateFormData}
            municipalDropdownOpen={municipalDropdownOpen}
            setMunicipalDropdownOpen={setMunicipalDropdownOpen}
            selectMunicipalLicense={selectMunicipalLicense}
          />
        );
      case 2:
        return (
          <Step2Attachments
            formData={formData}
            handleFileUpload={handleFileUpload}
          />
        );
      case 3:
        return (
          <Step3Agreements
            formData={formData}
            updateFormData={updateFormData}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-2" dir="rtl">
      <div className="w-full max-w-7xl bg-white rounded-lg shadow-lg">
        <div className="p-4">
          <div className="flex items-center justify-center mb-3">
            <Building className="h-5 w-5 text-blue-600 ml-2" />
            <h1 className="text-xl font-bold text-gray-900">
              تسجيل مكتب جديد
            </h1>
          </div>
          
          <StepIndicator currentStep={currentStep} totalSteps={3} />
          <StepTitles currentStep={currentStep} totalSteps={3} />
          
          <div className="mb-4" style={{ minHeight: '420px' }}>
            {renderCurrentStep()}
          </div>
          
          <div className="flex justify-between border-t pt-3">
            <button
              onClick={prevStep}
              disabled={currentStep === 1}
              className="flex items-center px-3 py-1.5 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-xs"
            >
              <ChevronRight className="h-3 w-3 ml-1" />
              السابق
            </button>
            
            {currentStep < 3 ? (
              <button
                onClick={nextStep}
                disabled={!isStepValid(currentStep, formData)}
                className="flex items-center px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-xs"
              >
                التالي
                <ChevronLeft className="h-3 w-3 mr-1" />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={!isStepValid(currentStep, formData)}
                className="flex items-center px-4 py-1.5 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-xs"
              >
                <CheckCircle className="h-3 w-3 ml-1" />
                إرسال الطلب
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;