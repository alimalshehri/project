import { MunicipalLicense } from '../types/FormTypes';

export const fetchIntegrationData = (): Promise<{
  officeName: string;
  officeCode: string;
  engineersLicense: string;
  engineersLicenseStart: string;
  engineersLicenseEnd: string;
  commercialRegister: string;
  commercialRegisterStart: string;
  commercialRegisterEnd: string;
  municipalLicenses: MunicipalLicense[];
  municipalClassification: string;
  classificationDegree: string;
  classificationEnd: string;
  nationalAddress: string;
  nationalAddressData: string;
  nationalAddressEnd: string;
  ownerId: string;
  ownerIdEnd: string;
  ownerMembership: string;
  ownerMembershipEnd: string;
}> => {
  return new Promise((resolve) => {
    // Simulate API call delay
    setTimeout(() => {
      const municipalLicenses: MunicipalLicense[] = [
        {
          id: '1',
          licenseNumber: 'ML-2024-001',
          municipalityName: 'أمانة المدينة المنورة',
          licenseEnd: '2025-12-31'
        },
        {
          id: '2',
          licenseNumber: 'ML-2024-002',
          municipalityName: 'بلدية المدينة المنورة',
          licenseEnd: '2025-06-30'
        },
        {
          id: '3',
          licenseNumber: 'ML-2024-003',
          municipalityName: 'أمانة منطقة المدينة المنورة',
          licenseEnd: '2025-09-15'
        }
      ];

      resolve({
        officeName: 'مكتب الهندسة المتطورة',
        officeCode: 'ENG-2024-001',
        engineersLicense: 'ENG-2024-12345',
        engineersLicenseStart: '2024-01-01',
        engineersLicenseEnd: '2025-12-31',
        commercialRegister: '1010123456',
        commercialRegisterStart: '2024-01-01',
        commercialRegisterEnd: '2025-12-31',
        municipalLicenses: municipalLicenses,
        municipalClassification: 'MC-001',
        classificationDegree: 'الدرجة الأولى',
        classificationEnd: '2025-12-31',
        nationalAddress: '1234567890',
        nationalAddressData: 'المدينة المنورة، المملكة العربية السعودية',
        nationalAddressEnd: '2025-12-31',
        ownerId: '1234567890',
        ownerIdEnd: '2030-12-31',
        ownerMembership: 'SEE-2024-001',
        ownerMembershipEnd: '2025-12-31'
      });
    }, 500);
  });
};