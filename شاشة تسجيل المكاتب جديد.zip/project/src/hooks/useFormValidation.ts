import { FormData } from '../types/FormTypes';

export const useFormValidation = () => {
  const isStepValid = (currentStep: number, formData: FormData): boolean => {
    switch (currentStep) {
      case 1:
        const hasBasicData = formData.officeType && formData.ownerId && formData.licenseNumber && formData.verificationData.officeName;
        const hasSelectedMunicipalLicense = formData.verificationData.selectedMunicipalLicense !== null;
        return hasBasicData && hasSelectedMunicipalLicense;
      case 2:
        return Object.values(formData.attachments).every(file => file !== null);
      case 3:
        return Object.values(formData.agreements).every(agreement => agreement);
      default:
        return false;
    }
  };

  return { isStepValid };
};